import unittest
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from network_sim import demo_network
from diagnostics import diagnose, feature_vector

class DiagnosticsTests(unittest.TestCase):
    def test_baseline_no_critical_findings(self):
        n = demo_network()
        codes = [x["Code"] for x in diagnose(n)]
        self.assertNotIn("IP-005", codes)
        self.assertNotIn("LINK-001", codes)

    def test_duplicate_ip(self):
        n = demo_network()
        n.hosts["PC-B"].ip = n.hosts["PC-A"].ip
        codes = [x["Code"] for x in diagnose(n)]
        self.assertIn("IP-005", codes)

    def test_bad_mask(self):
        n = demo_network()
        n.hosts["PC-A"].mask = "255.0.255.0"
        self.assertIn("IP-002", [x["Code"] for x in diagnose(n)])

    def test_link_down(self):
        n = demo_network()
        n.set_link("PC-A", "R1", False)
        self.assertIn("LINK-001", [x["Code"] for x in diagnose(n)])

    def test_feature_vector(self):
        n = demo_network()
        n.hosts["PC-B"].ip = n.hosts["PC-A"].ip
        features = feature_vector(diagnose(n))
        self.assertEqual(features["duplicate_ip"], 1)

if __name__ == "__main__":
    unittest.main()
